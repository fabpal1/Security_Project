

var main = function(){
    //acquisisco i numeri dei piatti ordinati
   $("header #invia").on("click", function(event) {
    event.preventDefault();

    // 1) Prima recuperiamo il CSRF token dal server
    $.get('/csrf-token')
      .done(function(data) {
        const csrfToken = data.csrfToken;

        // 2) Ciclo sui modelli
        for (let i = 1; i < 4; i++) {
          const count = parseInt($("#image-counter-" + i).text(), 10);
          if (count > 0) {
            const modello = $("#nr-" + i).text();
            const quantita = count;

            // 3) Invio la POST includendo il token nel header
            $.ajax({
              url: '/ordine',
              type: 'POST',
              contentType: 'application/json',
              data: JSON.stringify({ modello, quantita }),
              headers: {
                'CSRF-Token': csrfToken
              },
              success: function(result) {
                console.log('Ordine inviato:', result);
              },
              error: function(err) {
                console.error('Errore CSRF o altro:', err);
              }
            });

            // reset contatore per l'immagine i
            $("#image-counter-" + i).text(0);
          }
        }

        // reset display totale
        $("#count-display").text(0);
      })
      .fail(function(err) {
        console.error('Impossibile recuperare il CSRF token:', err);
      });
});

    $("#view-cert-button").on("click", function() {
        fetch('/cert')
            .then(response => {
                if (response.ok) {
                    return response.text();
                }
                throw new Error("Errore nel caricamento del certificato");
            })
            .then(cert => {
                $("#cert-display").text(cert);
            })
            .catch(error => {
                console.error(error);
                $("#cert-display").text("Errore nel caricamento del certificato");
            });
    });
}
function checkOrdini(){
    if($("#count-display").text() >= 29) {
        const button = document.querySelectorAll(".add-button");
        button.forEach(button => {
            button.disabled = true;
        });
    } else {
        const button = document.querySelectorAll(".add-button");
        button.forEach(button => {
            button.disabled = false;
        });
    }
}

function numOrdini(){
    var x = 0;
    for(var i = 1; i < 4; i++) { // Corretto il loop per includere New Balance
        var s = $("#image-counter-"+i).text();
        x += parseInt(s);
    }
    $("#count-display").text(x);
}
function toggleLoginForm() {
    var loginForm = document.getElementById("login-form");
    if (loginForm.style.display === "none" || loginForm.style.display === "") {
        loginForm.style.display = "block";
    } else {
        loginForm.style.display = "none";
    }
}
function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (!username || !password) {
        alert("Per favore, inserisci sia username che password.");
        return;
    }

    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        if (data.permissions.adminSection) {
            alert("Accesso consentito alla sezione admin.");
            document.getElementById('admin-section').style.display = 'block';
        } else {
            alert("Non hai i permessi per accedere alla sezione admin.");
            document.getElementById('admin-section').style.display = 'none';
        }
        console.log('Login riuscito. Ruolo:', data.role);
    })
    .catch(error => {
        console.error('Errore nel login:', error);
        alert("Errore durante il login. Riprovare.");
    });
}



function incrementImageCounter(imageNumber) {
    checkOrdini();
    var element = document.getElementById('image-counter-' + imageNumber);
    var currentCount = parseInt(element.innerText);
    element.innerText = currentCount + 1;
}

function decrementImageCounter(imageNumber) {
    checkOrdini();
    var element = document.getElementById('image-counter-' + imageNumber);
    var currentCount = parseInt(element.innerText);
    if(currentCount > 0) {
        element.innerText = currentCount - 1;
    }
}

function checktipo() {
    //completare codice andando a disattivare pulsante per pulsante quelli che non rispettano l'if
    for(var i = 1; i < 4; i++){
        if($("#image-counter-"+i).text() > 4) {
            const button = document.querySelector("#add-button-" + i);
            button.disabled = true;
        }
    }
}

setInterval(function() {
    numOrdini();
    //checktipo();
    //updateOrd();
}, 100);

$(document).ready(main);
