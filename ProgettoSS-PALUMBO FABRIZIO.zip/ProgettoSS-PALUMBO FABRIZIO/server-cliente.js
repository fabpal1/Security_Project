

const express = require("express"),
    http = require("http"),
    https = require("https"),
    fs = require("fs"),
    cors = require('cors'),
    mongoose = require("mongoose"),
    vault = require("node-vault"),
    xmlBuilder = require('xmlbuilder'),
    xml2js = require("xml2js");

const {Client} = require('ldapts');
const app = express();
const csrf = require('csurf');
const cookieParser = require('cookie-parser');

app.use(express.json()); 
app.use(express.static(__dirname + "/client"));
app.use(express.urlencoded());



app.use(cookieParser());

// Imposta il middleware CSRF (usa cookie per conservare il token)
const csrfProtection = csrf({ cookie: true });

// Aggiungi CORS per abilitare l'accesso alle tue risorse da un dominio diverso
app.use(cors({
    origin: 'https://localhost:8080', // Permetti l'accesso da HTTPS
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type'],
}));



const vaultClient = vault({
    apiVersion: "v1",
    endpoint: "http://127.0.0.1:8200",
    token: process.env.VAULT_TOKEN, //variabile d'ambiente, per evitare di scriverlo direttamente qui
});

// Recupero credenziali da Vault
async function getCredentialsFromVault() {
    try {
        const credentials = await vaultClient.read("my-secrets/credential");
        const { user, password } = JSON.parse(credentials.data.value);
        const uri = `mongodb://${user}:${password}@127.0.0.1:27017/dbss`;
        mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
            .then(() => console.log("Connesso a MongoDB"))
            .catch(err => console.error("Errore nella connessione a MongoDB:", err));
    } catch (err) {
        console.error("Errore nel recupero delle credenziali da Vault:", err);
    }
}
getCredentialsFromVault();


const LogSchema = mongoose.Schema({
    modello: { type: String },
    quantita: { type: String }
});

const Login = mongoose.model("Login", LogSchema);



async function getSSLFromVault() {
    try {
       
        const privateKeyResponse = await vaultClient.read('my-secrets/private-key');
        const certificateResponse = await vaultClient.read('my-secrets/certificate');
        
        const privateKey = privateKeyResponse.data.value;
        const certificate = certificateResponse.data.value;

        // Configura HTTPS con i dati da Vault
        const credentials = { key: privateKey, cert: certificate };
        const httpsPort = 8081;
        const httpsServer = https.createServer(credentials, app);

        httpsServer.listen(httpsPort, () => {
            console.log(`Server HTTPS creato, listen on port ${httpsPort}`);
        });
    } catch (err) {
        console.error('Errore nel recupero dei dati da Vault:', err);
    }
}

getSSLFromVault();


const LDAP_URL = 'ldap://localhost:389';  // Modifica con l'URL del tuo server LDAP
const BASE_DN = 'dc=example,dc=com';     // Modifica con il DN di base del tuo LDAP

async function authenticateLdapUser(username, passwordu, callback) {

    const client =  new Client({ url: LDAP_URL });
    const userDn = `uid=${username},ou=users,${BASE_DN}`;
    console.log('User DN:', userDn);

    try {

        const credentials = await vaultClient.read("my-secrets/ldap");
        const { user, password} = JSON.parse(credentials.data.value);
        // Effettua il bind con le credenziali amministrative
        await client.bind(`cn=${user},${BASE_DN}`,password);
        
        // Prepara la ricerca del gruppo
        const groupSearchOptions = {
            filter: `(&(objectClass=groupOfNames)(cn=premium)(member=${userDn}))`, // Usa il DN completo dell'utente
            scope: 'sub',
            attributes: ['cn'], // Recupera solo 'cn'
        };
        console.log('Group Search Filter:', groupSearchOptions.filter);

        // Esegui la ricerca
        const { searchEntries } = await client.search(`ou=groups,dc=example,dc=com`, groupSearchOptions);
        console.log(searchEntries);
        let userRole = 'default';
        if (searchEntries.length > 0) {
            console.log('Group found:', searchEntries);
            // Verifica che il gruppo 'premium' sia presente
            if (searchEntries[0].cn === 'premium') {
                userRole = 'premium';
            }
        }

        // Chiamata di ritorno con il risultato
        callback(null, true, userRole);

    } catch (err) {
        console.error('Errore durante il bind o la ricerca del gruppo:', err);
        callback(err);
    } finally {
        // Scollega il client
        await client.unbind();
    }
}




const httpPortNumbers = [3004, 3000, 3010];
httpPortNumbers.forEach(port => {
    const server = http.createServer(app).listen(port, () => {
        console.log(`Server HTTP creato, listen on port ${port}`);
    });
});


  
app.get("/cert", (req, res) => {
    res.sendFile(__dirname + '/server.cert');
app.get('/test-https', (req, res) => {
	res.send('Server HTTPS is running!');
});
});

// Rotta per ottenere tutti gli ordini dal database
app.get("/ordini", async (req, res) => {
    try {
        // Recupera tutti i documenti dalla collezione `Login`
        const ordini = await Login.find();

        // Risponde con i dati degli ordini
        res.status(200).json({ ordini });
    } catch (err) {
        console.error("Errore nel recupero degli ordini:", err);
        res.status(500).json({ error: "Errore interno del server" });
    }
});

app.post("/ordine",csrfProtection, async (req, res) => {
    try {
        const { modello, quantita } = req.body;

        // Verifica che i campi richiesti siano presenti
        if (!modello || !quantita) {
            return res.status(400).json({ error: "Modello e quantità sono richiesti" });
        }

        // Crea un nuovo documento utilizzando lo schema
        const nuovoOrdine = new Login({ modello, quantita });

        // Salva il documento nel database
        await nuovoOrdine.save();

        // Risposta di successo
        res.status(201).json({ message: "Ordine salvato con successo", ordine: nuovoOrdine });
    } catch (err) {
        console.error("Errore nel salvataggio dell'ordine:", err);
        res.status(500).json({ error: "Errore interno del server" });
    }
});
//token
app.get('/csrf-token', csrfProtection, (req, res) => {
    res.json({ csrfToken: req.csrfToken() });
});

// Rotta di login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username e password sono richiesti' });
    }

    // Autentica l'utente tramite LDAP
    authenticateLdapUser(username, password, async (err, success, role) => {
        if (err) {
            console.log(role);
            return res.status(401).json({ error: 'Credenziali non valide' });
           
        }
        console.log(role);
        if (success) {
            try {
                const jsonRequest = {
                    "Request": {
                        "AccessSubject": {
                            "Attribute": [
                                {
                                    "AttributeId": "urn:oasis:names:tc:xacml:1.0:subject:role",
                                    "Value": role
                                }
                            ]
                        },
                        "Resource": {
                            "Attribute": [
                                {
                                    "AttributeId": "urn:oasis:names:tc:xacml:1.0:resource:resource-id",
                                    "Value": "admin_section"
                                }
                            ]
                        },
                        "Action": {
                            "Attribute": [
                                {
                                    "AttributeId": "urn:oasis:names:tc:xacml:1.0:action:action-id",
                                    "Value": "access"
                                }
                            ]
                        }
                    }
                };
        
                console.log("json della richiesta:", jsonRequest);
                const credentials = await vaultClient.read("my-secrets/wso2");
                const { user, password } = JSON.parse(credentials.data.value);
                // Effettua la richiesta HTTP al server WSO2 (PDP) per la valutazione della policy
                fetch('https://localhost:9443/api/identity/entitlement/decision', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Basic ' + Buffer.from(`${user}:${password}`).toString('base64'),
                    },
                    body: JSON.stringify(jsonRequest),
                })
                .then(response => response.text())
                .then(decision => {
                    // Valuta la risposta del PDP
                    console.log("decisione:",decision);
                    const premiumAccess = decision?.Response?.Result?.Decision === 'Permit';

                    if (premiumAccess) {
                        // L'utente ha accesso alla sezione premium
                        res.status(200).json({
                            message: 'Login riuscito',
                            role: role,
                            permissions: {
                                premiumSection: true, // Permetti l'accesso alla sezione premium
                            },
                        });
                    } else {
                        // L'utente non ha accesso alla sezione premium
                        res.status(200).json({
                            message: 'Login riuscito',
                            role: role,
                            permissions: {
                                premiumSection: false,
                            },
                        });
                    }
                })
                .catch(error => {
                    console.error('Errore nella richiesta al server PDP:', error);
                    res.status(500).json({ error: 'Errore nel sistema di autorizzazione' });
                });
            } catch (err) {
                console.error('Errore nella richiesta al server WSO2:', err);
                res.status(500).json({ error: 'Errore nel sistema di autorizzazione' });
            }
        }
    });
});


