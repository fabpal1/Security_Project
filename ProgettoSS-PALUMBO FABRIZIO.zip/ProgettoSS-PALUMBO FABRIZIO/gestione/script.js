document.addEventListener("DOMContentLoaded", async () => {
    const tableBody = document.querySelector("#orders-table tbody");

    try {
        // Recupera l'access token da sessionStorage
        let accessToken = sessionStorage.getItem("keycloak_token");
        console.log(accessToken);
        console.log(sessionStorage);

        // Controlla se è presente nella query string (dopo il login)
        const urlParams = new URLSearchParams(window.location.search);
        const tokenFromQuery = urlParams.get("access_token");
        
        console.log(tokenFromQuery);
        console.log(urlParams);

        if (tokenFromQuery) {
            sessionStorage.setItem("keycloak_token", tokenFromQuery);
            accessToken = tokenFromQuery;

            // Rimuove il token dalla URL per motivi di sicurezza
            const url = new URL(window.location.href);
            url.searchParams.delete("access_token");
            window.history.replaceState({}, document.title, url.toString());
        }

       if (!accessToken) {
            console.warn("Access token non trovato. Reindirizzamento al login...");
            window.location.href = "/login";
            return;
        }

        // Effettua una chiamata GET al server per recuperare gli ordini
        const response = await fetch("/ordini", {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${accessToken}`,
            },
        });

        if (response.status === 401) {
            console.warn("Access token non valido. Reindirizzamento al login...");
            window.location.href = "/login";
            return;
        }

        if (!response.ok) {
            throw new Error(`Errore HTTP: ${response.status}`);
        }

        const data = await response.json();
        tableBody.innerHTML = ""; // Pulisce la tabella prima di popolarla

        data.ordini.forEach((ordine) => {
            const row = document.createElement("tr");
            const modelloCell = document.createElement("td");
            modelloCell.textContent = ordine.modello;
            row.appendChild(modelloCell);

            const quantitaCell = document.createElement("td");
            quantitaCell.textContent = ordine.quantita;
            row.appendChild(quantitaCell);

            tableBody.appendChild(row);
        });
    } catch (error) {
        console.error("Errore durante il caricamento degli ordini:", error);
        tableBody.innerHTML = `
            <tr>
                <td colspan="2" style="text-align: center; color: red;">
                    Errore nel caricamento degli ordini.
                </td>
            </tr>
        `;
    }
});
