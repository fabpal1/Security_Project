const express = require("express"),
        http = require("http"),
        https = require("https"),
        Keycloak = require("keycloak-connect"),
        mongoose = require("mongoose"),
        session = require("express-session"),
        uuid = require('uuid'),
        axios = require('axios'),
        jwt = require('jsonwebtoken'),
        vault = require("node-vault");

const app = express();
        
//altri middleware usati per conversione, indirizzamento dei file statici
app.use(express.json());
app.use(express.static(__dirname + "/gestione"));
app.use(express.urlencoded({ extended: true }));



const sessionStore = new session.MemoryStore();
app.use(
    session({
        secret: "mySecret",
        resave: false,
        saveUninitialized: true,
        store: sessionStore,
    })
);

// Connessione a Vault
const vaultClient = vault({
    apiVersion: "v1",
    endpoint: "http://127.0.0.1:8200",
    token: process.env.VAULT_TOKEN, 
});

// Configurazione Keycloak
let keycloak;
let keycloakConfig;
async function configureKeycloak() {
    try {
        const secretResponse = await vaultClient.read('my-secrets/ksecret');
        const mysecret = secretResponse.data.value; // Ottieni il secret dal Vault
        
        keycloakConfig = {
            clientId: "ecommerce-client",
            serverUrl: "http://localhost:8080",
            realm: "projectSS",
            credentials: {
                secret: mysecret, // Utilizza il secret recuperato
            },
            redirect_uri: 'https://localhost:8082/callback'
        };

        keycloak = new Keycloak({ store: sessionStore }, keycloakConfig);
        app.use(keycloak.middleware()); // Aggiungi il middleware di Keycloak
        console.log("Keycloak configurato con successo.");
        return keycloak;
    } catch (err) {
        console.error("Errore durante la configurazione di Keycloak:", err);
        throw err;
    }
}
configureKeycloak();

// Recupero credenziali da Vault
async function getCredentialsFromVault() {
    try {
        const credentials = await vaultClient.read("my-secrets/credential");
        const { user, password } = JSON.parse(credentials.data.value);
        const uri = `mongodb://${user}:${password}@127.0.0.1:27017/dbss`;
        mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
            .then(() => console.log("Connesso a MongoDB"))
            .catch(err => console.error("Errore nella connessione a MongoDB:", err));
    } catch (err) {
        console.error("Errore nel recupero delle credenziali da Vault:", err);
    }
}
getCredentialsFromVault();

async function getSSLFromVault() {
    try {
       
        const privateKeyResponse = await vaultClient.read('my-secrets/private-key');
        const certificateResponse = await vaultClient.read('my-secrets/certificate');
        
        const privateKey = privateKeyResponse.data.value;
        const certificate = certificateResponse.data.value;

        // Configura HTTPS con i dati da Vault
        const credentials = { key: privateKey, cert: certificate };
        const httpsPort = 8082;
        const httpsServer = https.createServer(credentials, app);

        httpsServer.listen(httpsPort, () => {
            console.log(`Server HTTPS creato, listen on port ${httpsPort}`);
        });
    } catch (err) {
        console.error('Errore nel recupero dei dati da Vault:', err);
    }
}

getSSLFromVault();

// Schema MongoDB
const LogSchema = mongoose.Schema({
    modello: { type: String },
    quantita: { type: String },
});
const Login = mongoose.model("Login", LogSchema);

// rotta protetto
app.get("/ordini", /*keycloak.protect('adminpolicy'),*/ async (req, res) => {
//verifica del ruolo nel codice come da esempio, la funzione keycloack non va
    try {
        const token = req.session.keycloak_token || (req.headers.authorization && req.headers.authorization.split(" ")[1]); 
        const decoded = jwt.decode(token); //per risolvere la vulnerabilità, dovrei settare keycloack per usare meccanismo a chiave pubblica/certificato, troppo complesso
        // Recupera i ruoli dal realm_access o resource_access
        const roles = decoded.realm_access?.roles || [];
        if(roles.includes('admin')){
            const ordini = await Login.find();
            res.status(200).json({ ordini });
        }else{
            res.status(403).send("accesso negato")
        }
    } catch (err) {
        console.error("Errore nel recupero degli ordini:", err);
        res.status(500).json({ error: "Errore interno del server" });
    }
});

// Login e callback

app.get("/login", (req, res) => {

    const state = uuid.v4();

    // Salva lo stato nella sessione per poterlo verificare successivamente
    req.session.state = state;

    const loginUrl = keycloak.loginUrl(state,"https://localhost:8082/callback");
    console.log("Login URL:", loginUrl); // Debug
    res.redirect(loginUrl);
});

app.get("/callback", async (req, res) => {
   // console.log("Query string ricevuta:", req.query); // Mostra i parametri ricevuti, debug

    try {
        
       const {state,code} = req.query;
        console.log(code);
        // Verifica che il parametro 'state' sia lo stesso di quello originale
        if (req.query.state !== req.session.state) {
            throw new Error("State mismatch. Possible CSRF attack.");
        }

        // Verifica che il codice sia presente nella query string
        if (!req.query.code) {
            throw new Error("Code non presente nella query string");
        }

        console.log("Code ricevuto:", req.query.code);
        //console.log(req.query);
        // Ottieni il grant utilizzando il codice
        /*const grant = await keycloak.grantManager.obtainFromCode(code); 
        console.log(grant);N.B. NON UTILIZZATO PERCHE' CON LA FUNZIONE SI GENERA ERRORE*/

        const tokenResponse = await axios.post('http://localhost:8080/realms/projectSS/protocol/openid-connect/token', new URLSearchParams({
            grant_type: 'authorization_code',
            code: code,
            redirect_uri: 'https://localhost:8082/callback',
            client_id: 'ecommerce-client',
            client_secret: keycloakConfig.credentials.secret, 
        }));

         
        const token = tokenResponse.data.access_token; // Salva il token nella sessione
        req.session.keycloak_token = token;

        console.log("Token ottenuto:",tokenResponse.data.access_token); 

        // Rimuovi lo stato dalla sessione dopo il callback
        delete req.session.state;

        res.redirect(`/index.html?access_token=${token}`); // Redirect 
    } catch (err) {
        console.error("Errore durante il callback:", err);
        res.status(500).json({ error: "Errore durante il callback" });
    }
});


// Avvio del server
const PORT = 3001;
app.listen(PORT, () => console.log(`Server in esecuzione su http://localhost:${PORT}`));
